import Layout from "../../components/Layout";
import SobreProps from "../../components/sobre";

export default function Sobre(){
    return (
        <>
      <Layout>
    <SobreProps/>
      </Layout>
        </>
    )
    }